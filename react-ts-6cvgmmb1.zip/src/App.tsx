import React, { useState } from "react";
import { supabase } from "./supabase";

const GOLD = "#C9A84C";
const GOLD_LIGHT = "#E8C97A";

const css = `
@import url('https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,600;1,300;1,400&family=Montserrat:wght@300;400;500;600&display=swap');
*{margin:0;padding:0;box-sizing:border-box}
body{background:#080808;color:#E8E0D0;font-family:'Montserrat',sans-serif}
nav{position:sticky;top:0;z-index:100;display:flex;justify-content:space-between;align-items:center;padding:20px 40px;background:rgba(8,8,8,0.95);border-bottom:1px solid rgba(201,168,76,0.15)}
.logo{font-family:'Cormorant Garamond',serif;font-size:26px;font-weight:300;letter-spacing:6px;color:${GOLD};text-transform:uppercase;cursor:pointer}
.logo em{font-style:italic}
.nav-links{display:flex;gap:24px;align-items:center}
.nav-btn{background:none;border:none;font-family:'Montserrat',sans-serif;font-size:10px;letter-spacing:3px;text-transform:uppercase;color:rgba(232,224,208,0.6);cursor:pointer;transition:color 0.3s}
.nav-btn:hover{color:${GOLD}}
.nav-cta{background:${GOLD};color:#080808;border:none;font-family:'Montserrat',sans-serif;font-size:10px;letter-spacing:3px;text-transform:uppercase;font-weight:600;padding:10px 22px;cursor:pointer}
.hero{min-height:90vh;display:flex;flex-direction:column;justify-content:center;align-items:center;text-align:center;padding:80px 40px;position:relative}
.hero-glow{position:absolute;inset:0;background:radial-gradient(ellipse at 50% 40%,rgba(201,168,76,0.07) 0%,transparent 65%);pointer-events:none}
.hero-line{width:1px;height:60px;background:linear-gradient(to bottom,transparent,${GOLD},transparent);margin:0 auto 32px}
.tag{font-size:9px;letter-spacing:6px;text-transform:uppercase;color:${GOLD};margin-bottom:20px}
.hero-title{font-family:'Cormorant Garamond',serif;font-size:clamp(52px,8vw,100px);font-weight:300;line-height:0.95;color:#F0E8D8;margin-bottom:20px}
.hero-title em{font-style:italic;color:${GOLD}}
.hero-sub{font-size:12px;letter-spacing:1.5px;color:rgba(232,224,208,0.35);max-width:380px;line-height:2;margin:0 auto 40px}
.btn-row{display:flex;gap:12px;justify-content:center;flex-wrap:wrap}
.btn-gold{padding:14px 36px;background:${GOLD};color:#080808;font-size:10px;letter-spacing:3px;text-transform:uppercase;font-family:'Montserrat',sans-serif;font-weight:600;border:none;cursor:pointer}
.btn-outline{padding:14px 36px;background:transparent;border:1px solid rgba(201,168,76,0.4);color:${GOLD};font-size:10px;letter-spacing:3px;text-transform:uppercase;font-family:'Montserrat',sans-serif;cursor:pointer}
.stats-row{display:flex;gap:48px;margin-top:64px;justify-content:center;flex-wrap:wrap}
.stat-num{font-family:'Cormorant Garamond',serif;font-size:34px;font-weight:300;color:${GOLD}}
.stat-lbl{font-size:9px;letter-spacing:3px;text-transform:uppercase;color:rgba(232,224,208,0.35);margin-top:4px}
.features{padding:80px 40px;max-width:1100px;margin:0 auto}
.feat-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:2px;margin-top:48px}
.feat-card{background:#0E0E0E;padding:40px 32px;border:1px solid rgba(201,168,76,0.06);transition:border-color 0.3s}
.feat-card:hover{border-color:rgba(201,168,76,0.3)}
.feat-n{font-family:'Cormorant Garamond',serif;font-size:44px;font-weight:300;color:rgba(201,168,76,0.18);margin-bottom:20px}
.feat-t{font-size:10px;letter-spacing:3px;text-transform:uppercase;color:${GOLD};margin-bottom:12px}
.feat-p{font-size:12px;color:rgba(232,224,208,0.35);line-height:1.9}
.sec-tag{font-size:9px;letter-spacing:5px;text-transform:uppercase;color:${GOLD};margin-bottom:14px}
.sec-title{font-family:'Cormorant Garamond',serif;font-size:clamp(32px,4vw,52px);font-weight:300;color:#F0E8D8;line-height:1.1;margin-bottom:20px}
.sec-title em{font-style:italic;color:${GOLD}}
.divider{width:48px;height:1px;background:${GOLD};margin-bottom:40px}
.form-wrap{max-width:680px;margin:0 auto;padding:100px 40px 80px}
.form-box{background:#0E0E0E;border:1px solid rgba(201,168,76,0.15);padding:56px}
.form-title{font-family:'Cormorant Garamond',serif;font-size:38px;font-weight:300;color:#F0E8D8;margin-bottom:6px}
.form-sub{font-size:10px;letter-spacing:2px;color:rgba(232,224,208,0.35);margin-bottom:40px}
.f-sec{font-size:9px;letter-spacing:4px;text-transform:uppercase;color:${GOLD};margin:28px 0 16px;padding-bottom:8px;border-bottom:1px solid rgba(201,168,76,0.15)}
.f-row{display:grid;grid-template-columns:1fr 1fr;gap:14px}
.f-group{margin-bottom:14px}
.f-label{display:block;font-size:9px;letter-spacing:2px;text-transform:uppercase;color:rgba(232,224,208,0.35);margin-bottom:8px}
.f-input{width:100%;background:#111;border:1px solid rgba(201,168,76,0.15);color:#E8E0D0;padding:13px 14px;font-family:'Montserrat',sans-serif;font-size:12px;transition:border-color 0.3s;outline:none}
.f-input:focus{border-color:${GOLD}}
.f-input::placeholder{color:rgba(232,224,208,0.25)}
textarea.f-input{min-height:90px;resize:vertical}
select.f-input{cursor:pointer;appearance:none}
.f-submit{width:100%;padding:16px;background:${GOLD};color:#080808;font-size:10px;letter-spacing:4px;text-transform:uppercase;font-family:'Montserrat',sans-serif;font-weight:600;border:none;cursor:pointer;margin-top:28px}
.f-submit:hover{background:${GOLD_LIGHT}}
.f-submit:disabled{opacity:0.5;cursor:not-allowed}
.f-note{font-size:10px;color:rgba(232,224,208,0.3);text-align:center;margin-top:14px;letter-spacing:1px}
.error-msg{background:rgba(255,80,80,0.08);border:1px solid rgba(255,80,80,0.2);color:rgba(255,120,120,0.9);padding:12px 16px;font-size:11px;margin-bottom:16px;letter-spacing:1px}
.success-msg{background:rgba(201,168,76,0.08);border:1px solid rgba(201,168,76,0.2);color:${GOLD};padding:12px 16px;font-size:11px;margin-bottom:16px;letter-spacing:1px}
.auth-wrap{max-width:480px;margin:0 auto;padding:100px 40px 80px}
.auth-box{background:#0E0E0E;border:1px solid rgba(201,168,76,0.15);padding:56px}
.auth-toggle{display:flex;margin-bottom:28px;border-bottom:1px solid rgba(201,168,76,0.15)}
.auth-tab{padding:10px 20px;font-size:9px;letter-spacing:3px;text-transform:uppercase;color:rgba(232,224,208,0.35);cursor:pointer;border:none;background:none;font-family:'Montserrat',sans-serif;border-bottom:2px solid transparent;margin-bottom:-1px;transition:all 0.3s}
.auth-tab.active{color:${GOLD};border-bottom-color:${GOLD}}
.pay-wrap{max-width:560px;margin:0 auto;padding:100px 40px 80px}
.pay-box{background:#0E0E0E;border:1px solid rgba(201,168,76,0.15);padding:56px}
.plan-card{background:#111;border:1px solid rgba(201,168,76,0.3);padding:28px;margin-bottom:32px}
.plan-name{font-size:10px;letter-spacing:4px;text-transform:uppercase;color:${GOLD};margin-bottom:8px}
.plan-price{font-family:'Cormorant Garamond',serif;font-size:52px;font-weight:300;color:#F0E8D8;line-height:1}
.plan-price span{font-size:16px;color:rgba(232,224,208,0.4)}
.plan-perks{margin-top:20px;display:flex;flex-direction:column;gap:8px}
.perk{font-size:11px;color:rgba(232,224,208,0.6);display:flex;align-items:center;gap:10px}
.perk::before{content:'✦';color:${GOLD};font-size:8px}
.dash-wrap{padding:100px 40px 80px;max-width:1100px;margin:0 auto}
.dash-header{display:flex;justify-content:space-between;align-items:flex-end;margin-bottom:40px;padding-bottom:24px;border-bottom:1px solid rgba(201,168,76,0.15)}
.dash-greeting{font-family:'Cormorant Garamond',serif;font-size:36px;font-weight:300;color:#F0E8D8}
.dash-greeting em{font-style:italic;color:${GOLD}}
.member-badge{font-size:9px;letter-spacing:3px;text-transform:uppercase;color:${GOLD};border:1px solid rgba(201,168,76,0.3);padding:6px 16px}
.matches-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:16px;margin-bottom:48px}
.match-card{background:#0E0E0E;border:1px solid rgba(201,168,76,0.08);overflow:hidden;cursor:pointer;transition:border-color 0.3s}
.match-card:hover{border-color:rgba(201,168,76,0.3)}
.match-photo{height:200px;display:flex;align-items:center;justify-content:center;position:relative}
.match-compat{position:absolute;top:12px;right:12px;background:rgba(8,8,8,0.85);padding:4px 10px;font-size:10px;color:${GOLD}}
.match-info{padding:20px}
.match-name{font-size:14px;font-weight:500;color:#F0E8D8;margin-bottom:4px}
.match-meta{font-size:11px;color:rgba(232,224,208,0.35);margin-bottom:10px}
.match-goal{font-size:11px;color:rgba(232,224,208,0.6);font-style:italic;line-height:1.6;margin-bottom:16px}
.match-btn{width:100%;padding:10px;background:transparent;border:1px solid rgba(201,168,76,0.2);color:${GOLD};font-size:9px;letter-spacing:3px;text-transform:uppercase;font-family:'Montserrat',sans-serif;cursor:pointer;transition:all 0.3s}
.match-btn:hover{background:${GOLD};color:#080808}
.rest-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:16px}
.rest-card{background:#0E0E0E;border:1px solid rgba(201,168,76,0.08);transition:border-color 0.3s}
.rest-card:hover{border-color:rgba(201,168,76,0.3)}
.rest-img{height:140px;display:flex;align-items:center;justify-content:center;font-size:40px;position:relative}
.rest-price{position:absolute;bottom:10px;right:12px;background:rgba(8,8,8,0.9);font-size:11px;color:${GOLD};padding:2px 8px}
.rest-body{padding:18px}
.rest-name{font-size:13px;font-weight:500;color:#F0E8D8;margin-bottom:4px}
.rest-cuisine{font-size:10px;letter-spacing:2px;text-transform:uppercase;color:rgba(232,224,208,0.35);margin-bottom:8px}
.rest-stars{color:${GOLD};font-size:11px;margin-bottom:12px}
.rest-btn{width:100%;padding:9px;background:transparent;border:1px solid rgba(201,168,76,0.2);color:${GOLD};font-size:9px;letter-spacing:2px;text-transform:uppercase;font-family:'Montserrat',sans-serif;cursor:pointer;transition:all 0.3s}
.rest-btn:hover{background:${GOLD};color:#080808}
.admin-wrap{padding:100px 40px 80px;max-width:1100px;margin:0 auto}
.admin-stats{display:grid;grid-template-columns:repeat(4,1fr);gap:2px;margin-bottom:40px}
.a-stat{background:#0E0E0E;border:1px solid rgba(201,168,76,0.08);padding:24px 28px}
.a-num{font-family:'Cormorant Garamond',serif;font-size:38px;font-weight:300;color:${GOLD}}
.a-lbl{font-size:9px;letter-spacing:3px;text-transform:uppercase;color:rgba(232,224,208,0.35);margin-top:4px}
.app-list{display:flex;flex-direction:column;gap:2px}
.app-row{background:#0E0E0E;border:1px solid rgba(201,168,76,0.06);padding:24px 28px;display:flex;align-items:center;gap:20px}
.av{width:44px;height:44px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-family:'Cormorant Garamond',serif;font-size:18px;color:#080808;flex-shrink:0}
.app-name-text{font-size:13px;font-weight:500;color:#F0E8D8;margin-bottom:3px}
.app-meta-text{font-size:10px;color:rgba(232,224,208,0.35);letter-spacing:1px}
.app-goal-text{font-size:11px;color:rgba(232,224,208,0.6);font-style:italic;max-width:260px;line-height:1.5;flex:1}
.app-acts{display:flex;gap:8px;flex-shrink:0}
.btn-approve{padding:8px 18px;background:transparent;border:1px solid rgba(201,168,76,0.4);color:${GOLD};font-size:9px;letter-spacing:2px;text-transform:uppercase;font-family:'Montserrat',sans-serif;cursor:pointer;transition:all 0.3s}
.btn-approve:hover{background:${GOLD};color:#080808}
.btn-reject{padding:8px 18px;background:transparent;border:1px solid rgba(255,80,80,0.2);color:rgba(255,100,100,0.5);font-size:9px;letter-spacing:2px;text-transform:uppercase;font-family:'Montserrat',sans-serif;cursor:pointer}
.badge{font-size:9px;letter-spacing:2px;text-transform:uppercase;padding:4px 12px;border:1px solid}
.badge-a{background:rgba(201,168,76,0.08);color:${GOLD};border-color:rgba(201,168,76,0.25)}
.badge-r{background:rgba(255,80,80,0.05);color:rgba(255,100,100,0.5);border-color:rgba(255,80,80,0.2)}
.success-screen{text-align:center;padding:120px 40px}
.success-icon{width:60px;height:60px;border:1px solid ${GOLD};border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 28px;font-size:22px;color:${GOLD}}
.success-title{font-family:'Cormorant Garamond',serif;font-size:44px;font-weight:300;color:#F0E8D8;margin-bottom:14px}
.success-text{font-size:12px;color:rgba(232,224,208,0.35);line-height:2;max-width:360px;margin:0 auto 36px}
footer{border-top:1px solid rgba(201,168,76,0.1);padding:40px;text-align:center}
.footer-logo{font-family:'Cormorant Garamond',serif;font-size:20px;color:${GOLD};letter-spacing:6px;text-transform:uppercase;margin-bottom:12px}
.footer-text{font-size:9px;letter-spacing:2px;color:rgba(232,224,208,0.2);text-transform:uppercase}
.loading{display:flex;align-items:center;justify-content:center;min-height:100vh;font-family:'Cormorant Garamond',serif;font-size:28px;font-weight:300;color:${GOLD};letter-spacing:4px}
`;

const matches = [
  { name: "Marcus T.", age: 29, city: "Los Angeles", occ: "SaaS Founder", goal: "Scaling to $1M ARR. Looking for someone who understands the grind.", compat: 94, bg: "linear-gradient(135deg,#2a1a08,#5a3510)" },
  { name: "Jordan K.", age: 26, city: "Chicago", occ: "Real Estate", goal: "Closing my first 10-unit deal. Building a long-term portfolio.", compat: 88, bg: "linear-gradient(135deg,#081a12,#0d4028)" },
  { name: "Serena V.", age: 31, city: "Austin", occ: "Brand Strategist", goal: "Launching my own agency after 6 years. Vision is clear.", compat: 85, bg: "linear-gradient(135deg,#1a0808,#401520)" },
];

const restaurants = [
  { name: "Elcielo", cuisine: "Contemporary Latin", stars: "★★★★★", price: "$$$$", emoji: "🕯️" },
  { name: "Alinea", cuisine: "Progressive American", stars: "★★★★★", price: "$$$$", emoji: "🍾" },
  { name: "Le Bernardin", cuisine: "Modern French", stars: "★★★★★", price: "$$$$", emoji: "✦" },
];

const avatarColors = ["#C9A84C", "#8B6914", "#E8C97A", "#A07830", "#D4A855"];

type View = "landing" | "login" | "apply" | "payment" | "success" | "dashboard" | "admin";

export default function App() {
  const [view, setView] = useState<View>("landing");
  const [authTab, setAuthTab] = useState<"login" | "signup">("login");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [successMsg, setSuccessMsg] = useState("");
  const [user, setUser] = useState<any>(null);

  const [loginEmail, setLoginEmail] = useState("");
  const [loginPassword, setLoginPassword] = useState("");
  const [signupFirstName, setSignupFirstName] = useState("");
  const [signupLastName, setSignupLastName] = useState("");
  const [signupEmail, setSignupEmail] = useState("");
  const [signupPassword, setSignupPassword] = useState("");

  const [form, setForm] = useState({
    first_name: "", last_name: "", age: "", city: "",
    occupation: "", income_range: "", linkedin: "",
    goal_3yr: "", current_building: "", partner_vision: ""
  });

  const [dbApps, setDbApps] = useState<any[]>([]);

  const handleLogin = async () => {
    setError(""); setLoading(true);
    const { data, error } = await supabase.auth.signInWithPassword({
      email: loginEmail, password: loginPassword
    });
    setLoading(false);
    if (error) { setError(error.message); return; }
    setUser(data.user);
    setView("dashboard");
  };

  const handleSignup = async () => {
    setError(""); setLoading(true);
    const { data, error } = await supabase.auth.signUp({
      email: signupEmail, password: signupPassword,
      options: { data: { first_name: signupFirstName, last_name: signupLastName } }
    });
    setLoading(false);
    if (error) { setError(error.message); return; }
    setUser(data.user);
    setSuccessMsg("Account created! Please check your email to confirm, then continue your application.");
    setTimeout(() => { setSuccessMsg(""); setView("apply"); }, 2500);
  };

  const handleSubmitApplication = async () => {
    setError(""); setLoading(true);
    const { error } = await supabase.from("applications").insert([{
      ...form,
      age: parseInt(form.age) || null,
      email: user?.email || signupEmail,
      status: "pending"
    }]);
    setLoading(false);
    if (error) { setError(error.message); return; }
    setView("payment");
  };

  const handleSignOut = async () => {
    await supabase.auth.signOut();
    setUser(null);
    setView("landing");
  };

  const loadAdminApps = async () => {
    const { data } = await supabase.from("applications").select("*").order("created_at", { ascending: false });
    if (data) setDbApps(data);
  };

  const updateStatus = async (id: string, status: string) => {
    await supabase.from("applications").update({ status }).eq("id", id);
    loadAdminApps();
  };

  const goToAdmin = () => {
    loadAdminApps();
    setView("admin");
  };

  const pending = dbApps.filter(a => a.status === "pending").length;
  const approved = dbApps.filter(a => a.status === "approved").length;
  const rejected = dbApps.filter(a => a.status === "rejected").length;

  return (
    <>
      <style>{css}</style>

      {/* NAV */}
      <nav>
        <div className="logo" onClick={() => setView("landing")}>Dev<em>ot</em>ion</div>
        <div className="nav-links">
          {user ? (
            <>
              <button className="nav-btn" onClick={() => setView("dashboard")}>Dashboard</button>
              <button className="nav-btn" onClick={handleSignOut}>Sign Out</button>
            </>
          ) : (
            <>
              <button className="nav-btn" onClick={() => setView("login")}>Sign In</button>
              <button className="nav-btn" onClick={goToAdmin}>Admin</button>
              <button className="nav-cta" onClick={() => setView("apply")}>Apply Now</button>
            </>
          )}
        </div>
      </nav>

      {/* LANDING */}
      {view === "landing" && (
        <>
          <div className="hero">
            <div className="hero-glow" />
            <div className="hero-line" />
            <p className="tag">Members-Only · Est. 2026</p>
            <h1 className="hero-title">Find Someone<br /><em>Worth Becoming</em></h1>
            <p className="hero-sub">A private network for driven individuals who refuse to settle — in life or in love.</p>
            <div className="btn-row">
              <button className="btn-gold" onClick={() => setView("apply")}>Request Membership</button>
              <button className="btn-outline" onClick={() => setView("login")}>Sign In</button>
            </div>
            <div className="stats-row">
              <div><div className="stat-num">$100</div><div className="stat-lbl">Per Month</div></div>
              <div><div className="stat-num">21+</div><div className="stat-lbl">Age Minimum</div></div>
              <div><div className="stat-num">Vetted</div><div className="stat-lbl">Every Member</div></div>
              <div><div className="stat-num">48hr</div><div className="stat-lbl">Review Time</div></div>
            </div>
          </div>
          <div className="features">
            <p className="sec-tag">The Standard</p>
            <h2 className="sec-title">Not for everyone.<br /><em>Built for the serious.</em></h2>
            <div className="divider" />
            <div className="feat-grid">
              {[
                { n: "01", t: "Human Verification", p: "Every application reviewed by a real person. We verify credentials, cross-reference LinkedIn, and confirm your story adds up." },
                { n: "02", t: "Direction Over Status", p: "We don't require wealth — we require direction. Broke but building? You qualify. Comfortable and coasting? You don't." },
                { n: "03", t: "Curated Date Venues", p: "After matching, we surface top restaurants in your city — upscale, vetted, with ratings and reservations built in." },
              ].map(f => (
                <div className="feat-card" key={f.n}>
                  <div className="feat-n">{f.n}</div>
                  <div className="feat-t">{f.t}</div>
                  <p className="feat-p">{f.p}</p>
                </div>
              ))}
            </div>
          </div>
          <footer>
            <div className="footer-logo">Devotion</div>
            <p className="footer-text">© 2026 · Private Membership · All Rights Reserved</p>
          </footer>
        </>
      )}

      {/* LOGIN */}
      {view === "login" && (
        <div className="auth-wrap">
          <div className="auth-box">
            <p className="sec-tag">Member Access</p>
            <h2 className="form-title">Welcome back.</h2>
            <p className="form-sub">Sign in to your Devotion account</p>
            <div className="auth-toggle">
              <button className={`auth-tab ${authTab === "login" ? "active" : ""}`} onClick={() => { setAuthTab("login"); setError(""); }}>Sign In</button>
              <button className={`auth-tab ${authTab === "signup" ? "active" : ""}`} onClick={() => { setAuthTab("signup"); setError(""); }}>Create Account</button>
            </div>
            {error && <div className="error-msg">{error}</div>}
            {successMsg && <div className="success-msg">{successMsg}</div>}
            {authTab === "login" ? (
              <>
                <div className="f-group"><label className="f-label">Email</label><input className="f-input" placeholder="your@email.com" type="email" value={loginEmail} onChange={e => setLoginEmail(e.target.value)} /></div>
                <div className="f-group"><label className="f-label">Password</label><input className="f-input" placeholder="••••••••" type="password" value={loginPassword} onChange={e => setLoginPassword(e.target.value)} /></div>
                <button className="f-submit" onClick={handleLogin} disabled={loading}>{loading ? "Signing in..." : "Sign In to Devotion"}</button>
              </>
            ) : (
              <>
                <div className="f-row">
                  <div className="f-group"><label className="f-label">First Name</label><input className="f-input" placeholder="Alexandra" value={signupFirstName} onChange={e => setSignupFirstName(e.target.value)} /></div>
                  <div className="f-group"><label className="f-label">Last Name</label><input className="f-input" placeholder="Monroe" value={signupLastName} onChange={e => setSignupLastName(e.target.value)} /></div>
                </div>
                <div className="f-group"><label className="f-label">Email</label><input className="f-input" placeholder="your@email.com" type="email" value={signupEmail} onChange={e => setSignupEmail(e.target.value)} /></div>
                <div className="f-group"><label className="f-label">Password</label><input className="f-input" placeholder="Create a password" type="password" value={signupPassword} onChange={e => setSignupPassword(e.target.value)} /></div>
                <button className="f-submit" onClick={handleSignup} disabled={loading}>{loading ? "Creating account..." : "Continue to Application"}</button>
              </>
            )}
          </div>
        </div>
      )}

      {/* APPLICATION */}
      {view === "apply" && (
        <div className="form-wrap">
          <div className="form-box">
            <p className="sec-tag">Membership Application</p>
            <h2 className="form-title">Tell us who you are.</h2>
            <p className="form-sub">$100/month · Human-reviewed · 24–48hr response</p>
            {error && <div className="error-msg">{error}</div>}
            <div className="f-sec">Personal Information</div>
            <div className="f-row">
              <div className="f-group"><label className="f-label">First Name</label><input className="f-input" placeholder="Alexandra" value={form.first_name} onChange={e => setForm({ ...form, first_name: e.target.value })} /></div>
              <div className="f-group"><label className="f-label">Last Name</label><input className="f-input" placeholder="Monroe" value={form.last_name} onChange={e => setForm({ ...form, last_name: e.target.value })} /></div>
            </div>
            <div className="f-row">
              <div className="f-group"><label className="f-label">Age</label><input className="f-input" placeholder="Must be 21+" value={form.age} onChange={e => setForm({ ...form, age: e.target.value })} /></div>
              <div className="f-group"><label className="f-label">City</label><input className="f-input" placeholder="New York" value={form.city} onChange={e => setForm({ ...form, city: e.target.value })} /></div>
            </div>
            <div className="f-sec">Professional Background</div>
            <div className="f-row">
              <div className="f-group"><label className="f-label">Occupation</label><input className="f-input" placeholder="Founder / Finance / Pre-med..." value={form.occupation} onChange={e => setForm({ ...form, occupation: e.target.value })} /></div>
              <div className="f-group">
                <label className="f-label">Income Range</label>
                <select className="f-input" value={form.income_range} onChange={e => setForm({ ...form, income_range: e.target.value })}>
                  <option value="">Select range</option>
                  <option>Still building / In school</option>
                  <option>Under $50k</option>
                  <option>$50k – $100k</option>
                  <option>$100k – $250k</option>
                  <option>$250k+</option>
                </select>
              </div>
            </div>
            <div className="f-group"><label className="f-label">LinkedIn Profile URL</label><input className="f-input" placeholder="linkedin.com/in/yourname" value={form.linkedin} onChange={e => setForm({ ...form, linkedin: e.target.value })} /></div>
            <div className="f-sec">Vision & Direction</div>
            <div className="f-group"><label className="f-label">Where do you want to be in 3 years?</label><textarea className="f-input" placeholder="Be specific. Vague answers are grounds for rejection." value={form.goal_3yr} onChange={e => setForm({ ...form, goal_3yr: e.target.value })} /></div>
            <div className="f-group"><label className="f-label">What are you actively building right now?</label><textarea className="f-input" placeholder="What's the work? What's the progress?" value={form.current_building} onChange={e => setForm({ ...form, current_building: e.target.value })} /></div>
            <div className="f-group"><label className="f-label">What does your ideal partner look like in terms of ambition?</label><textarea className="f-input" placeholder="Not looks — vision, drive, lifestyle..." value={form.partner_vision} onChange={e => setForm({ ...form, partner_vision: e.target.value })} /></div>
            <button className="f-submit" onClick={handleSubmitApplication} disabled={loading}>{loading ? "Submitting..." : "Continue to Payment →"}</button>
            <p className="f-note">Reviewed within 24–48 hours · $100/mo billed after approval</p>
          </div>
        </div>
      )}

      {/* PAYMENT */}
      {view === "payment" && (
        <div className="pay-wrap">
          <div className="pay-box">
            <p className="sec-tag">Final Step</p>
            <h2 className="form-title" style={{ marginBottom: 6 }}>Complete Membership</h2>
            <p className="form-sub">Billed monthly after approval. Cancel anytime.</p>
            <div className="plan-card">
              <div className="plan-name">Devotion Membership</div>
              <div className="plan-price">$100<span>/mo</span></div>
              <div className="plan-perks">
                {["Full access to verified member profiles", "Ambition-based matching algorithm", "Curated restaurant recommendations", "Direct messaging with matches", "Human-reviewed quality assurance"].map(p => (
                  <div className="perk" key={p}>{p}</div>
                ))}
              </div>
            </div>
            <div className="f-group"><label className="f-label">Cardholder Name</label><input className="f-input" placeholder="Alexandra Monroe" /></div>
            <div className="f-group"><label className="f-label">Card Number</label><input className="f-input" placeholder="4242 4242 4242 4242" /></div>
            <div className="f-row">
              <div className="f-group"><label className="f-label">Expiry</label><input className="f-input" placeholder="MM / YY" /></div>
              <div className="f-group"><label className="f-label">CVC</label><input className="f-input" placeholder="•••" /></div>
            </div>
            <button className="f-submit" onClick={() => setView("success")}>Activate Membership · $100/mo</button>
            <p className="f-note">🔒 Secured by Stripe · Card charged after approval</p>
          </div>
        </div>
      )}

      {/* SUCCESS */}
      {view === "success" && (
        <div className="success-screen">
          <div className="success-icon">✦</div>
          <h2 className="success-title">Application Received</h2>
          <p className="success-text">Your application is under review. Our team will assess your profile within 24–48 hours. If approved, your membership activates immediately.</p>
          <button className="btn-outline" onClick={() => setView("landing")} style={{ marginTop: 32 }}>Return Home</button>
        </div>
      )}

      {/* DASHBOARD */}
      {view === "dashboard" && (
        <div className="dash-wrap">
          <div className="dash-header">
            <div>
              <h2 className="dash-greeting">Good evening, <em>{user?.user_metadata?.first_name || "Member"}</em></h2>
              <p style={{ fontSize: 10, letterSpacing: 2, color: "rgba(232,224,208,0.35)", marginTop: 6 }}>3 new matches this week</p>
            </div>
            <div className="member-badge">Active Member</div>
          </div>
          <p className="sec-tag">Your Matches</p>
          <h3 style={{ fontFamily: "'Cormorant Garamond',serif", fontSize: 28, fontWeight: 300, color: "#F0E8D8", marginBottom: 24 }}>People worth knowing.</h3>
          <div className="matches-grid">
            {matches.map(m => (
              <div className="match-card" key={m.name}>
                <div className="match-photo" style={{ background: m.bg }}>
                  <span style={{ fontFamily: "'Cormorant Garamond',serif", fontSize: 52, fontWeight: 300, color: "rgba(201,168,76,0.6)" }}>{m.name[0]}</span>
                  <div className="match-compat">{m.compat}% match</div>
                </div>
                <div className="match-info">
                  <div className="match-name">{m.name}</div>
                  <div className="match-meta">{m.age} · {m.city} · {m.occ}</div>
                  <div className="match-goal">"{m.goal}"</div>
                  <button className="match-btn">View Profile</button>
                </div>
              </div>
            ))}
          </div>
          <div style={{ marginBottom: 24 }}>
            <p className="sec-tag">Date Venues Near You</p>
            <h3 style={{ fontFamily: "'Cormorant Garamond',serif", fontSize: 28, fontWeight: 300, color: "#F0E8D8", marginBottom: 8 }}>Curated for the occasion.</h3>
            <p style={{ fontSize: 11, color: "rgba(232,224,208,0.35)", marginBottom: 24, letterSpacing: 1 }}>Upscale restaurants · Updated weekly</p>
          </div>
          <div className="rest-grid">
            {restaurants.map(r => (
              <div className="rest-card" key={r.name}>
                <div className="rest-img" style={{ background: "linear-gradient(135deg,#0e0a02,#2a1f08)" }}>
                  <span style={{ fontSize: 36 }}>{r.emoji}</span>
                  <div className="rest-price">{r.price}</div>
                </div>
                <div className="rest-body">
                  <div className="rest-name">{r.name}</div>
                  <div className="rest-cuisine">{r.cuisine}</div>
                  <div className="rest-stars">{r.stars}</div>
                  <button className="rest-btn">Reserve a Table</button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ADMIN */}
      {view === "admin" && (
        <div className="admin-wrap">
          <div style={{ marginBottom: 36, paddingBottom: 20, borderBottom: "1px solid rgba(201,168,76,0.15)" }}>
            <p className="sec-tag">Admin Panel</p>
            <h2 style={{ fontFamily: "'Cormorant Garamond',serif", fontSize: 36, fontWeight: 300, color: "#F0E8D8" }}>Review Dashboard</h2>
          </div>
          <div className="admin-stats">
            {[
              { n: pending, l: "Awaiting Review" },
              { n: approved, l: "Approved Members" },
              { n: rejected, l: "Rejected" },
              { n: `$${approved * 100}`, l: "Monthly Revenue" },
            ].map(s => (
              <div className="a-stat" key={s.l}>
                <div className="a-num">{s.n}</div>
                <div className="a-lbl">{s.l}</div>
              </div>
            ))}
          </div>
          <p className="sec-tag" style={{ marginBottom: 16 }}>Applications</p>
          {dbApps.length === 0 ? (
            <p style={{ color: "rgba(232,224,208,0.3)", fontSize: 12, letterSpacing: 2 }}>No applications yet. They will appear here once people apply.</p>
          ) : (
            <div className="app-list">
              {dbApps.map((a, i) => (
                <div className="app-row" key={a.id}>
                  <div className="av" style={{ background: avatarColors[i % avatarColors.length] }}>{a.first_name?.[0] || "?"}</div>
                  <div style={{ flex: "0 0 180px" }}>
                    <div className="app-name-text">{a.first_name} {a.last_name}</div>
                    <div className="app-meta-text">{a.age} · {a.city}</div>
                    <div className="app-meta-text">{a.occupation}</div>
                  </div>
                  <div className="app-goal-text">"{a.goal_3yr}"</div>
                  <div className="app-acts">
                    {a.status === "pending" ? (
                      <>
                        <button className="btn-approve" onClick={() => updateStatus(a.id, "approved")}>Approve</button>
                        <button className="btn-reject" onClick={() => updateStatus(a.id, "rejected")}>Reject</button>
                      </>
                    ) : (
                      <span className={`badge ${a.status === "approved" ? "badge-a" : "badge-r"}`}>{a.status}</span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </>
  );
}