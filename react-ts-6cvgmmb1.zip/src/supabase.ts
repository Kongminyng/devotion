import { createClient } from '@supabase/supabase-js'

const supabaseUrl = 'https://skohpwaljkdtcjximnui.supabase.co'
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InNrb2hwd2FsamtkdGNqeGltbnVpIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Nzk5OTc5MTMsImV4cCI6MjA5NTU3MzkxM30.CXtBOLCVK16fZ60SLk47fimUIGwWmVYCKtnzQpzBCvo'

export const supabase = createClient(supabaseUrl, supabaseAnonKey)